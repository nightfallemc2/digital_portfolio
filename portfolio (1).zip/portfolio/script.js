(function(){
const get=k=>{try{return localStorage.getItem(k)}catch(e){return null}},set=(k,v)=>{try{localStorage.setItem(k,v)}catch(e){}};
const bn=document.querySelector('.banner');
if(bn){const sl=[...bn.querySelectorAll('.slide')],dots=bn.querySelector('.dots'),f=document.getElementById('file');let cur=0,mode='R',timer;
 sl.forEach((s,i)=>{const pf=s.querySelector('.pf'),ov=s.querySelector('.ov'),p=get('pf'+i),l=get('ov'+i);
  if(p)pf.src=p;
  const ld=u=>{ov.onload=()=>{ov.hidden=false};ov.src=u};ld(l||'assets/slide-'+(i+1)+'.jpg');
  const d=document.createElement('button');d.setAttribute('aria-label','Go to slide '+(i+1));d.onclick=()=>{go(i);auto()};dots.appendChild(d);});
 function go(n){cur=(n+sl.length)%sl.length;sl.forEach((s,i)=>s.classList.toggle('on',i===cur));dots.querySelectorAll('button').forEach((d,i)=>d.classList.toggle('on',i===cur));}
 function auto(){clearInterval(timer);if(!matchMedia('(prefers-reduced-motion:reduce)').matches)timer=setInterval(()=>go(cur+1),5500);}
 bn.querySelector('.p').onclick=()=>{go(cur-1);auto()};bn.querySelector('.n').onclick=()=>{go(cur+1);auto()};
 bn.onmouseenter=bn.onfocusin=()=>clearInterval(timer);bn.onmouseleave=bn.onfocusout=auto;
 document.getElementById('chgR').onclick=()=>{mode='R';f.click()};document.getElementById('chgL').onclick=()=>{mode='L';f.click()};
 f.onchange=()=>{const file=f.files[0];if(!file)return;const r=new FileReader();r.onload=()=>{const s=sl[cur];
  if(mode==='R'){s.querySelector('.pf').src=r.result;set('pf'+cur,r.result)}else{const o=s.querySelector('.ov');o.hidden=false;o.src=r.result;set('ov'+cur,r.result)}};r.readAsDataURL(file);f.value='';};
 go(0);auto();}
const q=document.getElementById('quote');
if(q){const s=get('quote');if(s)q.innerHTML=s;q.oninput=()=>set('quote',q.innerHTML);}
if(typeof POSTS!=='undefined'){
 const box=document.getElementById('posts'),fl=document.getElementById('filters');
 const tags=['All',...new Set(POSTS.map(p=>p.tag))];
 const show=t=>{box.innerHTML=POSTS.filter(p=>t==='All'||p.tag===t).sort((a,b)=>b.date.localeCompare(a.date)).map(p=>`<article class="post"><time datetime="${p.date}">${new Date(p.date).toLocaleDateString('en-GB',{day:'numeric',month:'long',year:'numeric'})}</time><h3>${p.title}</h3>${p.body}</article>`).join('')||'<p>No posts yet.</p>';
  fl.querySelectorAll('button').forEach(b=>b.classList.toggle('on',b.textContent===t));};
 fl.innerHTML=tags.map(t=>`<button>${t}</button>`).join('');fl.onclick=e=>{if(e.target.tagName==='BUTTON')show(e.target.textContent)};show('All');}
})();
