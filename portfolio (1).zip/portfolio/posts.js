// Add new posts at the top. Fields: title, date (YYYY-MM-DD), tag, body (HTML allowed).
const POSTS=[
{title:"Hunting the missing baryons",date:"2026-09-01",tag:"Astronomy",body:"<p>Much of the universe's ordinary matter hides in hot, thin gas between galaxies. Here is how stacking tSZ maps with FRB dispersion measures can reveal it.</p>"},
{title:"Building this portfolio on GitHub Pages",date:"2026-08-15",tag:"Web",body:"<p>Plain HTML, CSS and a little JavaScript. No build step, no framework, free hosting.</p>"},
{title:"Replace me with your first real post",date:"2026-08-01",tag:"Data",body:"<p>Edit posts.js, commit, and your blog updates.</p>"}
];
